// a growable (DA) array of ints
#include <stdio.h>
#include <stdlib.h>

typedef struct GAChar {
	char * data; // dynamically allocated array of chars
	unsigned all; // # of bytes used in data (all-used bytes of UG)
	unsigned used; // # of bytes allocated in data
} GAChar;

void appendInputChar(GAChar * gaCharPtr);
int die(const char * msg);
void show(const GAChar * gaPtr);

int main() {
	GAChar ga;
	ga.data = NULL;
	ga.all = 0;
	ga.used = 0;
	printf("Please input a line: ");
	for (int ch; (ch = getchar()) != EOF && ch != '\n';) {
		ungetc(ch, stdin);
		appendInputChar(&ga);
	}
	show(&ga);
	free(ga.data); // deallocate
}
/*appendInputChar's  job  is  to  get  a  char  with  getchar  (you  can  assume  without 
checking that there's no input failure) and append that char to the growable array.
Naturally,  this  will  involve  a  reallocation  if  the  currently  allocate  array  in  the 
growable array is full. C&d on allocation failure
*/
void appendInputChar(GAChar * gaCharPtr){
	char ch = getchar();
	if (gaCharPtr->used == gaCharPtr->all) {
		int newAll = gaCharPtr->all + 10;
		gaCharPtr->data = realloc(gaCharPtr->data, newAll * sizeof(*gaCharPtr));
		if (gaCharPtr->data == NULL)  die("appendInputChar: allocation failure");
		gaCharPtr->all = newAll;
	}
	gaCharPtr->data[gaCharPtr->used] = ch;
	gaCharPtr->used++;
}
int die(const char * msg) {
	printf("Fatal error: %s\n", msg);
	exit(EXIT_FAILURE);
}

// display values in growable array
void show(const GAChar * gaCharPtr) {
	printf("GA[%u/%u]:", gaCharPtr->used, gaCharPtr->all);
	for (unsigned i = 0; i < gaCharPtr->used; i++)
		printf("%c", gaCharPtr->data[i]);
	printf("\n");
}