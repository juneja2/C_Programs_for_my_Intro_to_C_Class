// CS 539, Midterm Program B, Parshant Juneja
#include <stdio.h>
#include <stdlib.h>
unsigned addRange(unsigned lo, unsigned hi); // [lo, hi)
int prime(unsigned n);
int main() {
	printf("200 + 201 + 202 + 203 ... + 300 = %u\n",addRange(200, 301));
	unsigned n;
	printf("Please enter a positive number ");
	scanf_s("%u", &n);
	int isPrime = 0;
	unsigned i = n;
	for (; i > 1; i--) {
		
		isPrime = prime(i);
		if (isPrime == 1)
			break;
	}
	if (isPrime == 1) {
		printf("%u\n", i);
	}
	else printf("No primes found\n");
}
unsigned addRange(unsigned lo, unsigned hi) {
	unsigned sum = 0;
	for (unsigned i = lo; i < hi; i++)
		sum += i;
	return sum;
}
int prime(unsigned n) {
	unsigned divisor = n / 2;
	for (unsigned i = divisor; i > 1; i--) {
		if (n % i == 0)
			return 0;
	}
	return 1;
}// 1 means that its prime 0 means it's not
