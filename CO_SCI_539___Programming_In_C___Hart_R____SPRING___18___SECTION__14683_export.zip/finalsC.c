//CS 539 FinalsC Parshant Juneja
#include <stdio.h>
#include <stdlib.h>

double * doubleIt(const double * ptr, unsigned els);
void die(char * msg);
void show(double * arr, unsigned els);

int main() {
	double arr[] = { 1.1,   2.2,   3.3 };
	show(arr, 3);

	double * ptr = doubleIt(arr, 3);
	show(ptr, 6);

	free(ptr);
	return 0;
}
double * doubleIt(const double * ptr, unsigned els) {

	double * newArray = malloc((els * 2) * sizeof(*ptr));
	if (newArray == NULL)
		die("Wasn't able to allocate memory in doubleIt");
	for (int i = 0; i < els; i++) {
		newArray[i] = ptr[i];
		newArray[i + els] = ptr[i];
	}
	return newArray;
}

void die(char * msg) {
	printf("%s", msg);
	exit(EXIT_FAILURE);
}
void show(double * arr, unsigned els) {
	for (unsigned i = 0; i < els; i++)
		printf("%f\n", arr[i]);
}