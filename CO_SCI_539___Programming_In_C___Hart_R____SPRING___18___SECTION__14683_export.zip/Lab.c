// Lab 3 Arrays, Parshant Juneja, CS 539

#include <stdio.h>
#include <stdlib.h>

void show(const double a[], unsigned elements);
double sum(const double a[], unsigned elements);
void half(double a[], unsigned elements);
void add(double result[], const double a0[], const double a1[],
	unsigned elements);
void maximum(double result[], const double a0[], const double a1[],
	unsigned elements);
void stat(double * smallest, double * average, double * largest,
	const double a[], unsigned elements);
void setFib(unsigned result[], unsigned elements);
void reverse(double a[], unsigned elements);
int die(const char msg[]);

int main() {
	double a0[4] = { 1.1,2.2,3.3,4.4 }, a1[4] = { 7,6,8,5 }, result[4];
	printf("Printing array 1:\n"); show(a0, 4);
	printf("Printing array 2:\n"); show(a1, 4);
	double sumOfArray1 = sum(a0, 4);
	double sumOfArray2 = sum(a1, 4);
	printf("Sum Of Array 1 = %0.3f Sum Of Array 2 = %0.3f\n", sumOfArray1, sumOfArray2);
	half(a1, 4);
	printf("After halfing the entire 2nd array:\n"); show(a1, 4);
	add(result, a0, a1, 4);
	printf("Result[i] = a0[i] + a1[i]:\n"); show(result, 4);
	maximum(result, a0, a1, 4);
	printf("Print result again where max of a0[i] or a1[i] is set to result[i]\n"); show(result, 4);

	double smallestOfArray0, largestOfArray0, averageOfArray0;
	stat(&smallestOfArray0, &averageOfArray0, &largestOfArray0, a0, 4);
	printf("Smallest number = %.3f, Largest number = %.3f, average = %.3f of array1\n",
		smallestOfArray0, largestOfArray0, averageOfArray0);
	stat(&smallestOfArray0, &averageOfArray0, &largestOfArray0, a1, 4);
	printf("Smallest number = %.3f, Largest number = %.3f, average = %.3f of array2\n",
		smallestOfArray0, largestOfArray0, averageOfArray0);
	stat(&smallestOfArray0, &averageOfArray0, &largestOfArray0, result, 4);
	printf("Smallest number = %.3f, Largest number = %.3f, average = %.3f of result\n",
		smallestOfArray0, largestOfArray0, averageOfArray0);

	unsigned newResult[8];
	setFib(newResult, 8);
	printf("Printing fibonnaci number from newResult array:\n");
	printf("%u", newResult[0]);
	for (unsigned i = 1; i < 8; i++)
		printf(", %u", newResult[i]);
	printf("\n");

	reverse(result, 4);
	printf("Reversing Result array\n");
	printf("%f", result[0]);
	for (unsigned i = 1; i < 4; i++)
		printf(", %f", result[i]);
	printf("\n");
	setFib(newResult, 0);
	return 0;
}
void show(const double a[], unsigned elements) {
	printf("%.3f", a[0]);
	for (unsigned i = 1; i < elements; i++)
		printf(", %0.3f", a[i]);
	printf("\n");
}
double sum(const double a[], unsigned elements) {
	double sum = 0;
	for (unsigned i = 0; i < elements; i++)
		sum += a[i];
	return sum;
}
void half(double a[], unsigned elements) {
	for (unsigned i = 0; i < elements; i++)
		a[i] /= 2;
}
void add(double result[], const double a0[], const double a1[],
	unsigned elements) {
	for (unsigned i = 0; i < elements; i++)
		result[i] = a0[i] + a1[i];
}
void maximum(double result[], const double a0[], const double a1[],
	unsigned elements) {
	for (unsigned i = 0; i < elements; i++) {
		if (a0[i] >= a1[i])
			result[i] = a0[i];
		else result[i] = a1[i];
	}
}
void stat(double * smallest, double * average, double * largest,
	const double a[], unsigned elements) {

	if (elements == 0)
		die("#  of  elements  is  0,  then  smallest,  average,  and  largest  are  undefined. Quitting\n");
	else {
		*average = sum(a, elements) / elements;

		unsigned maxIndex = 0, minIndex = 0;
		for (unsigned j = 1; j < elements; j++)
		{
			if (a[maxIndex] < a[j])
				maxIndex = j;
			if (a[j] < a[minIndex])
				minIndex = j;
		}
		*largest = a[maxIndex];
		*smallest = a[minIndex];
	}
}
void setFib(unsigned result[], unsigned elements) {
	unsigned fib[] = { 0, 1 };
	if (elements > 0) {
		for (unsigned i = 0; i < elements; i++) {
			result[i] = fib[0];
			unsigned temp = fib[0];
			fib[0] = fib[1];
			fib[1] = temp + fib[1];
		}
	}
	else die("Number of elements = 0, not able to set newResult to fibonnaci numbers:Quitting\n");
}
void reverse(double a[], unsigned elements) {
	for (unsigned i = 0; i < elements / 2; i++) {
		double temp = a[i];
		a[i] = a[elements - i - 1];
		a[elements - i - 1] = temp;
	}
}
int die(const char msg[]) {
	printf("%s", msg);
	exit(EXIT_FAILURE);
}