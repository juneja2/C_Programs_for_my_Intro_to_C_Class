#include <stdio.h>
#include <stdlib.h>
void statistics(double * negAve, double * posMin, const double ar[], unsigned els);
int main() {
	unsigned size = 7;
	double ar[] = { -3.0,  -2.0,  -1.0,  0.0,  2.2,  1.1,  3.3 };
	double negAve;
	double posMin;
	statistics(&negAve, &posMin, ar, size);
	printf("Negative average = %f and smallest positive number = %f\n", negAve, posMin);
}
void statistics(double * negAve, double * posMin, const double ar[], unsigned els) {
	int foundPositive = 0;
	int totalNeg = 0;
	*negAve = 0;
	for (unsigned i = 0; i < els; i++) {
		if (ar[i] < 0) {
			*negAve += ar[i];
			totalNeg++;
		}
		else if (ar[i] > 0 && foundPositive == 0) {
			*posMin = ar[i];
			foundPositive = 1;
		}
		else if (ar[i] > 0 && foundPositive == 1)
			if(ar[i] < *posMin) {
			*posMin = ar[i];
		}
	}
	*negAve /= totalNeg;
}
