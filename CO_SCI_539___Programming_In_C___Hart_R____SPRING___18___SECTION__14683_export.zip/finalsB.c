#include <stdio.h>
#include <math.h>

void sort(unsigned arr[], unsigned els);
int compare(const void * ptr0, const void * ptr1);
void show(unsigned arr[], unsigned els);
int main() {
	
	unsigned arr[] = { 102,  101,  100,  100,  99,  98 };
	
	show(arr, 6);
	printf("\n");

	sort(arr, 6);
	show(arr, 6);


	return 0;
}
void show(unsigned arr[], unsigned els) {
	for (unsigned i = 0; i < els; i++)
		printf("%u\n", arr[i]);
}
void sort(unsigned arr[], unsigned els) {
	qsort(arr, els, sizeof(*arr), compare);
}
int compare(const void * ptr0, const void * ptr1) {
	unsigned number0 = *(unsigned *)ptr0;
	unsigned number1 = *(unsigned *)ptr1;

	unsigned distNumber0From100 = abs(number0 - 100);
	unsigned distNumber1From100 = abs(number1 - 100);
	
	if (distNumber0From100 == distNumber1From100)
		return number0 < number1 ? -1 : number0 > number1 ? 1 : 0;
	else if (distNumber0From100 < distNumber1From100)
		return -1;
	else return 1;

}
