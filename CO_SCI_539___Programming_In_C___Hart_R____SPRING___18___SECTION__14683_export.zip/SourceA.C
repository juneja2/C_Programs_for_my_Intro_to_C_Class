//CS 539, Midterm Program A, Parshant Juneja
#include <stdio.h>
#include <stdlib.h>
const long unsigned c = 299792458;
void die(char * msg);
double mass(double joules);
int main() {
	double joules;
	printf("Please enter number of joules ");
	if (scanf_s("%lf", &joules) != 1) {
		die("Input failure - Wasn't able to enter number of joules");
	}
	printf("Joules %f = %f kg\n", joules, mass(joules));
	return 0;
}
void die(char * msg) {
	printf("Fatal error: %s\n", msg);
	exit(EXIT_FAILURE);
}
double mass(double joules) {
	if (joules < 0)
		die("Joules can't be negative");
	return (joules / c) / c;
}