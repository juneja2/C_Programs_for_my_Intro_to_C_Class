#include <stdio.h>


void show(unsigned n);
unsigned f(unsigned n);

int main() {
	show(3570919570);
	show(f(3570919570));
	return 0;
}
void show(unsigned n) {
	for (int bp = 32; bp--;)
		printf("%i%s", ((n >> bp) & 1U), bp % 8 ? "" : bp == 0 ? "\n" : " ");
}
unsigned f(unsigned n) {
	n |= 4026531840; // 4026531840 = 11110000 00000000 00000000 00000000
	n &= 4026793983; // 4026793983 = 11110000 00000011 11111111 11111111
	n ^= 511;        // 511        = 00000000 00000000 00000001 11111111
	return n;

}
/*
setting the bit field (32, 28] (that is, bits #31, 30, 29, and 28) to 1-bits
resetting the bit field (28, 18] to 0-bits
leaving the bits (18, 9] unchanged
flipping the bits (9, 0].
*/