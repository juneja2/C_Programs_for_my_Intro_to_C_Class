// CS 539, Midterm Program B, Parshant Juneja
#include <stdio.h>
#include <stdlib.h>


int compare(const void * ptr0, const void * ptr1);
int main() {
	int size = 8;
	int ar[] = { 4, -4, 3, -3, 2, -2, 1, -1 };
	printf("before sorting   ");
	for (int i = 0; i < size; i++)
		printf("%i   ", ar[i]);
	qsort(ar, size, sizeof(*ar), compare);
	printf("\nafter sorting   ");
	for (int i = 0; i < size; i++)
		printf("%i   ", ar[i]);
}
int compare(const void * ptr0, const void * ptr1) {
	double x0 = *(const int*)ptr0;
	double x1 = *(const int*)ptr1;
	if (x0 < 0 && x1 < 0 && x0 < x1) {
		return 1;
	}
	else if (x0 < 0 && x1 > 0)
		return -1;
	else if (x0 > 0 && x1 < 0)
		return 1;
	else if (x0 < x1) // at this point both of them are even
		return 1;
	else return -1;
}